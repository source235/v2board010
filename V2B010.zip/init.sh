php artisan key:generate
php artisan config:cache
